import { TextField } from '@mui/material'
import type { Entity } from 'host/compiled-types/models'
import React from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { Controller } from 'react-hook-form'

type NameFieldProps = Readonly<{
  formProps: UseFormReturn<Entity>
}>

const NameField: React.FC<NameFieldProps> = ({ formProps }) => {
  return (
    <Controller
      name='name'
      control={formProps.control}
      rules={{
        required: 'Entity Name is required',
        maxLength: { value: 128, message: 'Maximum 128 characters' }
      }}
      render={({ field: { ref, value, ...field }, fieldState: { error } }) => {
        return (
          <TextField
            {...field}
            inputRef={ref}
            value={value ?? ''}
            fullWidth
            label='Entity Name'
            required
            error={Boolean(error)}
            helperText={error?.message}
            disabled={formProps.formState.disabled}
            slotProps={{ inputLabel: { shrink: true } }}
          />
        )
      }}
    />
  )
}

export default NameField
